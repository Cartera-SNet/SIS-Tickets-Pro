"""
Login multi-empresa estilo Esculapio
Extraído del proyecto Esculapio Soft CM RailWay
Solo lo necesario para autenticación: servidor → usuario/contraseña → empresa
"""
import os
import time
import logging
from datetime import timedelta
from functools import wraps
from flask import Flask, render_template, request, jsonify, session, redirect, url_for

try:
    import requests as req_lib
except ImportError:
    raise SystemExit("Instala requests: pip install requests")

# APIs Esculapio
API_SERVIDORES = "https://appsintranet.esculapiosis.com/ApiCampbell/api/Usuarios/obtener-servidores"
API_EMPRESAS   = "https://appsintranet.esculapiosis.com/ApiCampbell/api/Usuarios/obtener-empresas"

_cache_servidores = None
_cache_servidores_ts = 0

def _get_servidores_api():
    global _cache_servidores, _cache_servidores_ts
    if _cache_servidores and (time.time() - _cache_servidores_ts) < 300:
        return _cache_servidores
    try:
        resp = req_lib.get(API_SERVIDORES, timeout=10, verify=False)
        resp.raise_for_status()
        data = resp.json()
        _cache_servidores    = data if isinstance(data, list) else []
        _cache_servidores_ts = time.time()
        return _cache_servidores
    except Exception as e:
        print(f"Error consultando servidores: {e}")
        return _cache_servidores or []

def _get_empresas_api(ip, puerto, usuario, password):
    try:
        params = {
            "IpConexion":   ip,
            "BdConexion":   "bd",
            "PortConexion": puerto,
            "Usuario":      usuario,
            "PasswordUsu":  password,
        }
        resp = req_lib.get(API_EMPRESAS, params=params, timeout=15, verify=False)
        resp.raise_for_status()
        data = resp.json()
        return data if isinstance(data, list) else []
    except Exception as e:
        print(f"Error empresas: {e}")
        return []

# Flask
logging.basicConfig(level=logging.INFO, format="%(message)s")
app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "login-esculapio-key")
app.permanent_session_lifetime = timedelta(hours=8)

# Rate limiting simple
_login_intentos = {}
_LOGIN_MAX = 5
_LOGIN_VENTANA = 600
_LOGIN_BLOQUEO = 900

def _check_rate(ip):
    ahora = time.time()
    d = _login_intentos.get(ip, {})
    if d.get("bloqueado_hasta", 0) > ahora:
        r = int(d["bloqueado_hasta"] - ahora)
        return False, f"IP bloqueada. Intenta en {r//60}m {r%60}s."
    if ahora - d.get("primer_intento", 0) > _LOGIN_VENTANA:
        _login_intentos.pop(ip, None)
    return True, ""

def _fail(ip):
    ahora = time.time()
    d = _login_intentos.get(ip, {})
    if not d or ahora - d.get("primer_intento", 0) > _LOGIN_VENTANA:
        d = {"intentos": 0, "primer_intento": ahora}
    d["intentos"] += 1
    if d["intentos"] >= _LOGIN_MAX:
        d["bloqueado_hasta"] = ahora + _LOGIN_BLOQUEO
    _login_intentos[ip] = d

def _ok(ip):
    _login_intentos.pop(ip, None)

def login_requerido(f):
    @wraps(f)
    def dec(*a, **kw):
        if not session.get("autenticado"):
            if request.is_json or request.path.startswith("/api/"):
                return jsonify({"error": "No autorizado", "login_required": True}), 401
            return redirect(url_for("login_page"))
        return f(*a, **kw)
    return dec

@app.route("/")
def root():
    return redirect(url_for("login_page"))

@app.route("/login")
def login_page():
    if session.get("autenticado"):
        return jsonify({
            "mensaje": "Ya estás autenticado",
            "usuario": session.get("usuario"),
            "servidor": session.get("servidor"),
            "empresa": session.get("empresa"),
        })
    return render_template("login.html")

@app.route("/api/servidores")
def get_servidores():
    try:
        servidores = _get_servidores_api()
        data = {}
        for srv in servidores:
            nombre = srv.get("Descripcion", "").strip()
            if nombre:
                data[nombre] = {
                    "id":     srv.get("$id", ""),
                    "ip":     srv.get("Ip_Conexion", ""),
                    "puerto": str(srv.get("Puerto", "3306")),
                    "usuario_default": srv.get("Usuario", ""),
                }
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/api/auth/conectar", methods=["POST"])
def auth_conectar():
    """Paso 1: valida credenciales y devuelve empresas (sin crear sesión aún)."""
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "").split(",")[0].strip()
    ok, msg = _check_rate(ip)
    if not ok:
        return jsonify({"error": msg}), 429

    data     = request.get_json() or {}
    usuario  = data.get("usuario", "").strip()
    password = data.get("password", "").strip()
    servidor = data.get("servidor", "").strip()

    if not all([usuario, password, servidor]):
        return jsonify({"error": "Completa todos los campos"}), 400

    servidores = _get_servidores_api()
    srv = next((s for s in servidores if s.get("Descripcion","").strip() == servidor), None)
    if not srv:
        return jsonify({"error": f"Servidor '{servidor}' no encontrado"}), 404

    ip_srv = srv.get("Ip_Conexion", "")
    puerto = str(srv.get("Puerto", "3306"))

    empresas_raw = _get_empresas_api(ip_srv, puerto, usuario, password)
    if not empresas_raw:
        _fail(ip)
        d = _login_intentos.get(ip, {})
        r = max(0, _LOGIN_MAX - d.get("intentos", 1))
        return jsonify({"error": f"Credenciales inválidas. {r} intento(s) restantes."}), 401

    empresas = [{"cod": e.get("Empresa",""), "nombre": e.get("Nombre_Empresa",""), "sede": e.get("NombreComercial","")}
                for e in empresas_raw if e.get("Empresa")]
    _ok(ip)
    print(f"Conectado: {usuario}@{servidor} — {len(empresas)} empresa(s)")
    return jsonify({"success": True, "empresas": empresas, "ip": ip_srv, "puerto": puerto})

@app.route("/api/auth/login", methods=["POST"])
def auth_login():
    ip = request.headers.get("X-Forwarded-For", request.remote_addr or "").split(",")[0].strip()
    ok, msg = _check_rate(ip)
    if not ok:
        return jsonify({"error": msg}), 429

    data     = request.get_json() or {}
    usuario  = data.get("usuario", "").strip()
    password = data.get("password", "").strip()
    servidor = data.get("servidor", "").strip()
    empresa  = data.get("empresa",  "").strip()
    empresas = data.get("empresas", [])

    if not all([usuario, password, servidor, empresa]):
        return jsonify({"error": "Datos incompletos"}), 400

    servidores = _get_servidores_api()
    srv = next((s for s in servidores if s.get("Descripcion","").strip() == servidor), None)
    if not srv:
        return jsonify({"error": "Servidor no encontrado"}), 404

    ip_srv = srv.get("Ip_Conexion", "")
    puerto = str(srv.get("Puerto", "3306"))

    session.permanent      = True
    session["autenticado"] = True
    session["usuario"]     = usuario
    session["password"]    = password
    session["servidor"]    = servidor
    session["ip"]          = ip_srv
    session["puerto"]      = puerto
    session["empresa"]     = empresa
    session["empresas"]    = empresas
    print(f"Sesión creada: {usuario}@{servidor} empresa={empresa}")
    return jsonify({"success": True})

@app.route("/api/auth/logout", methods=["POST"])
def auth_logout():
    session.clear()
    return jsonify({"success": True})

@app.route("/api/auth/me")
def auth_me():
    if session.get("autenticado"):
        empresa_cod = session.get("empresa", "")
        empresas    = session.get("empresas", [])
        empresa_nombre = empresa_cod
        for e in empresas:
            if e.get("cod") == empresa_cod:
                nombre = e.get("nombre", empresa_cod)
                sede   = e.get("sede", "")
                empresa_nombre = f"{empresa_cod} — {nombre}" + (f" {sede}" if sede else "")
                break
        return jsonify({
            "autenticado":    True,
            "usuario":        session.get("usuario", ""),
            "servidor":       session.get("servidor", ""),
            "empresa":        empresa_cod,
            "empresa_nombre": empresa_nombre,
            "empresas":       empresas,
        })
    return jsonify({"autenticado": False}), 401

if __name__ == "__main__":
    print("Login Esculapio listo en http://127.0.0.1:5000")
    app.run(host="0.0.0.0", port=5000, debug=True)
