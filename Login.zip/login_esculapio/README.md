# Login multi-empresa estilo Esculapio

Solo el flujo de autenticación (servidor → usuario/contraseña → empresa).

## Cómo correrlo

```bash
pip install -r requirements.txt
python app.py
```

Abre http://127.0.0.1:5000

## Endpoints principales

- `GET  /api/servidores`          → lista de servidores
- `POST /api/auth/conectar`       → valida credenciales y devuelve empresas
- `POST /api/auth/login`          → crea la sesión con la empresa elegida
- `GET  /api/auth/me`             → datos de la sesión actual
- `POST /api/auth/logout`         → cierra sesión

## Notas

- Usa las APIs públicas de Esculapio (`appsintranet.esculapiosis.com`).
- La sesión se guarda en Flask (cookie).
- Incluye rate limiting básico contra fuerza bruta.
